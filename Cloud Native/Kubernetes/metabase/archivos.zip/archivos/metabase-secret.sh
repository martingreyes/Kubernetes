kubectl create secret generic metabase-secret \
    --from-literal=db-username=root \
    --from-literal=db-password=tele \
    --from-literal=db-name=datos \
    --from-literal=db-type=mysql \
    -o yaml \
    --dry-run=client > metabase-secret.yaml