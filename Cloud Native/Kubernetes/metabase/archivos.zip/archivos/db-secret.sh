kubectl create secret generic db-secret \
    --from-literal=db-username=root \
    --from-literal=db-password=tele \
    --from-literal=db-name=datos \
    -o yaml \
    --dry-run=client > db-secret.yaml
